import UIKit
// Autor: Julian Padilla Molina
// Curso de swift
// Mini reto - Semana 2

// Variable con rango desde 0 al 100 contandolo
var numeros = 0...100

// Numeros que son divisibles en 5 del rango del 0 a 100
print("\nEstos son los siguientes numeros divisibles en 5:\n")

//For each para iterar sobre el rango de numeros
for numActual in numeros
{
    if(numActual % 5) == 0
    {
        print("\(numActual) Bingo!!!")
    }
}

// Numeros pares del rango del 0 a 100
print("\nEstos son los siguientes numeros pares:\n")

//For each para iterar sobre el rango de numeros
for numActual in numeros
{
    if(numActual % 2) == 0
    {
        print("\(numActual) par!!!")
    }
}

// Numeros impares del rango del 0 a 100
print("\nEstos son los siguientes numeros impares:\n")

//For each para iterar sobre el rango de numeros
for numActual in numeros
{
    if(numActual % 2) == 1
    {
        print("\(numActual) impar!!!")
    }
}

// Numeros que se encuntran entre 30 y 40
print("\nEstos son los siguientes numeros que se encuntran en el rango del 30 a 40:\n")

//For each para iterar sobre el rango de numeros
for numActual in numeros
{
    if numActual >= 30 && numActual <= 40
    {
        print("\(numActual) Viva swift!!!")
    }
}



